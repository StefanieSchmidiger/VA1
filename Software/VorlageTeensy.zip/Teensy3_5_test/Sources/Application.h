/*
 * Application.h
 *
 *  Created on: 10.10.2017
 *      Author: Erich Styger Local
 */

#ifndef SOURCES_APPLICATION_H_
#define SOURCES_APPLICATION_H_


void APP_Run(void);


#endif /* SOURCES_APPLICATION_H_ */
