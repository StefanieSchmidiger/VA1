/*
 * Platform.h
 *
 *  Created on: 10.10.2017
 *      Author: Erich Styger Local
 */

#ifndef SOURCES_PLATFORM_H_
#define SOURCES_PLATFORM_H_



#define PL_HAS_SHELL  (1)
#define PL_HAS_SD_CARD (1)

#endif /* SOURCES_PLATFORM_H_ */
